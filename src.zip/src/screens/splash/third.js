

import React from 'react'
import { Text , View } from 'react-native'

const Third = () => {
    return (
        <View>
            <Text style = {{width: 500}}>
                THIRD SCREEN 
            </Text>
        </View>
    )
}

export default Third