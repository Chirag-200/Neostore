
import React from 'react'
import { Text , View } from 'react-native'

const ForgetPassword = () => {
    return (
       <View>
<Text style = {{ }}>Password Recovery </Text>
       </View>
    )
}

export default ForgetPassword