

export default GroupImages = {
    Bubble2: require('../images/bubble02.png'),
}